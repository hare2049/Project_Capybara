var express = require('express');
var router = express.Router();
var pg = require('pg');

var config = {
    user: 'nasturtiums',
    database: 'capybara',
    password: 'nodeprojekt',
    host: 'localhost',
    port: 5432,
    max: 100,
    idleTimeoutMillis: 30000,
};

var pool = new pg.Pool(config);


router.get('/', async (req, res, next) => {
    pool.connect(async (err,client,done) => {
        if (err) {
            return res.send(err);
        }
        console.log(req.cookies.secret);
        console.log('aa');
        client.query(`SELECT l_username FROM session WHERE secret = $1`, [req.cookies.secret], async(err, result) => {
            if(err){
                return res.send(err);
            }else{
                //res.cookie('username', result.rows[0].l_username, {maxAge: 2*60*60*1000});
                client.query(`SELECT * FROM lecture WHERE $1 = l_username;`, [req.cookies.username], async (req,res,next)=> {
                    done();
                    console.log(result.rows);
                    return res.render('predavac', {title: 'predavac', username: req.body.usernamel, tabela: result.rows});
                })            }
        })
    })
});

router.get('/predavanja', function (req, res, next) {
    console.log('u predavanjima');
    pool.connect(async (err, client, done) => {
        if(err)
            return res.send(err);
        client.query(`SELECT * FROM lecture WHERE $1 = l_username;`, [req.cookies.username], async (req,res,next)=>{
            done();
            if(err)
                res.send(err);
            console.log(result.rows);
            return res.send(result.rows);
        })
    })
})

module.exports = router;
