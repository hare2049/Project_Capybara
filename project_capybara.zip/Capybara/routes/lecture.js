var express = require('express');
var router = express.Router();
var pg = require('pg');

var config = {
    user: 'nasturtiums',
    database: 'capybara',
    password: 'nodeprojekt',
    host: 'localhost',
    port: 5432,
    max: 100,
    idleTimeoutMillis: 30000,
};

var pool = new pg.Pool(config);


router.get('/:code', async(req,res, result)=>{
    console.log('u otvaranju predavanja backend');
    console.log(req.params.code)
    pool.connect(async (err,client,done) => {
        if(err) return res.send(err);
        client.query(`SELECT code, title FROM lecture where code = $1`, [req.params.code], async(err, result) => {
            done()
            if(err) return err;
            else {
                console.log(result.rows[0].code);
                console.log('ovde sam');
                res.render('lecture', {title: result.rows[0].title});
                console.log('kod enda');
                res.end();
            }
        })
    })
})


module.exports = router;
