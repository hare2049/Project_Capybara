var express = require('express');
var router = express.Router();
var bcrypt = require('bcrypt');
var pg = require('pg');
var multer = require('multer')
var path = require('path')
var session = require('express-session');
var cookieParser = require('cookie-parser');

const storage = multer.diskStorage({
  destination: (req,file,cb) => {
    cb(null, 'images')
  },
  filename: (req, file, cb) => {
    console.log(file)
    cb(null, Date.now() + path.extname(file.originalname))
  }
})

const upload = multer({storage: storage})

var config = {
  user: 'nasturtiums',
  database: 'capybara',
  password: 'nodeprojekt',
  host: 'localhost',
  port: 5432,
  max: 100,
  idleTimeoutMillis: 30000,
};

var pool = new pg.Pool(config);

router.get('/', async(req, res, next) => {
  /*
  console.info(res.cookie());
  if(res.cookie()) {*/
  console.log('index /');
  pool.connect(async (err,client,done) => {
    if(err)
      return res.send(err);
    if(req.cookies.yes === '1'){
      client.query(`SELECT * FROM lecture WHERE $1 = l_username;`, [req.cookies.username], async (err, result)=> {
        if(err) return res.send(err)
        done();
        if(req.cookies.admin === false)
          return res.render('predavac', {title: 'predavac', username: req.cookies.username, tabela: result.rows});
        else
          return res.render('predavac', {title: 'predavac', username: req.cookies.username, tabela: result.rows, admin: req.cookies.admin});
      })
    }else
      return res.render('index', {title: 'Capybara'});
  })
  /*
}
else{
  res.render('predavac', {username: req.cookie.greetingName});
}*/
});

router.get('/usernames', async(req,res,next) => {
  pool.connect(async (err,client,done) => {
    if(err){
      return res.send(err);
    }
    client.query(`SELECT username FROM lecturer`, [], async(err, result) => {
      done();
      if(err){
        return res.send(err);
      }else{
        return res.send({response: result.rows});
      }
    })
  })
})

router.post('/lectures', upload.single("image"), async (req, res, next) => {
  pool.connect(async (err, client, done) =>{
    if(err)
      return res.send(err);
    console.log('luctures');
    console.log(req.body.code);
    client.query(`INSERT INTO lecture(code, title, time, image, l_username) values($1, $2, $3, $4, $5)`,
        [req.body.code, req.body.title, req.body.time, 'aaaaa', req.body.l_username], async (err, result)=>{
      done();
      if(err)
        res.send(err);
      else{
        console.log('jel uopste ovde')
        res.send({nesto: 'nekakva vrijednost'});
      }
    })
  })
});

router.delete('/deleteLecture', async(req,res,next) => {
  console.log('u delete lecture');
  pool.connect(async(err,client,done) => {
    if(err)
      return res.send(err);
    console.log(req.body.code);
    client.query(`DELETE FROM lecture WHERE code = $1`, [req.body.code], async (err, result) => {
      done()
      if(err) return err;
      else {
        res.send({nesto: 'nekakva vrijednost'});
      }
    })
  })
})

router.get('/emails', async(req,res,next) => {
  pool.connect(async (err,client,done) =>{
    if(err){
      return res.send(err);
    }
    client.query(`SELECT email FROM lecturer`, [], async(err, result) => {
      done();
      if(err){
        return res.send(err);
      }else{
        return res.send({response: result.rows});
      }
    })
  })
})

router.post('/signup', async(req, res) => {
  pool.connect(async (err,client,done) => {
    if(err){
      return res.send(err);
    }

    if(req.body.email === '') {
      bcrypt.hash(req.body.password1, 10, async(err, hash) => {
        client.query(`INSERT INTO lecturer(username, password) values($1, $2)`, [req.body.username, hash], async (err) => {
          if (err) {
            return res.send(err);
          } else {
            bcrypt.hash(hash.slice(0,2) + req.body.username + (Math.floor(Math.random() * 101)).toString(), 10, async(err, hash) => {
              /*
              session({
                secret: hash,
                saveUninitialized: true,
                cookie: {maxAge: 1000 * 60 * 60 * 24},
                resave: false
              });
              */
              res.cookie('yes', 1, {maxAge: 2*60*60*1000});
              res.cookie('username', req.body.username, {maxAge: 2*60*60*1000});
              res.cookie('secret', hash, {maxAge: 2*60*60*1000});
              client.query(`INSERT INTO session VALUES($1,$2, to_timestamp($3))`, [hash, req.body.username, Date.now()+2*60*60*1000], async(err) => {
                if(err) return res.send(err);
                client.query(`SELECT * FROM lecture WHERE $1 = l_username;`, [req.cookies.username], async (err, result)=> {
                  if(err) return err;
                  done();
                  return res.render('predavac', {title: 'predavac', username: req.body.username, tabela: result.rows, admin: false});
                })
              })
            });
          }
        })
      });
    }
    else {
      bcrypt.hash(req.body.password1, 10, async(err, hash) => {
        client.query(`INSERT INTO lecturer(username, password, email) values($1, $2, $3)`, [req.body.username, hash, req.body.email], async (err) => {
          if (err) {
            return res.send(err);
          } else {
            bcrypt.hash(hash.slice(0,2) + req.body.username + Math.floor(Math.random() * 101).toString(), 10, async(err, hash) => {
              /*
              session({
                secret: hash,
                saveUninitialized: true,
                cookie: {maxAge: 1000 * 60 * 60 * 24},
                resave: false
              });
              */
              res.cookie('yes', 1, {maxAge: 2*60*60*1000});
              res.cookie('username', req.body.username, {maxAge: 2*60*60*1000});
              res.cookie('secret', hash, {maxAge: 2*60*60*1000});
                client.query(`INSERT INTO session VALUES($1,$2, to_timestamp($3))`, [hash, req.body.username, Date.now()+2*60*60*1000], async (err) => {
                if (err) return res.send(err);
                  client.query(`SELECT * FROM lecture WHERE $1 = l_username;`, [req.cookies.username], async (err, result)=> {
                    done();
                    if(err) return err;
                    return res.render('predavac', {title: 'predavac', username: req.body.username, tabela: result.rows, admin: false});
                  })
                })
            })
          }
        })
      });
    }
  })
});

router.post('/login', async(req, res) => {
  console.log('U loginu sam');
  pool.connect(async (err,client,done) => {
    if (err) {
      return res.send(err);
    }

    client.query(`SELECT username, password, admin from lecturer`, [], async (err, result) => {
      console.log(result.rows);
      if(err) return err;
      for(let i = 0; i < result.rows.length; i++) {
        console.log(result.rows[i]);
        if (req.body.usernamel === result.rows[i].username) {
            if (await bcrypt.compare(req.body.passwordl, result.rows[i].password)) {
              console.log('na pravom');
              await bcrypt.hash(req.body.passwordl.slice(0,2) + req.body.usernamel + Math.floor(Math.random() * 101).toString(), 10, async(err, hash) => {
                /*
                session({
                  secret: hash,
                  saveUninitialized: true,
                  cookie: {maxAge: 1000 * 60 * 60 * 24},
                  resave: false
                });
                */
                res.cookie('yes', 1, {maxAge: 2*60*60*1000});
                res.cookie('username', req.body.usernamel, {maxAge: 2*60*60*1000});
                res.cookie('secret', hash, {maxAge: 2*60*60*1000});
                res.cookie('admin', result.rows[i].admin, {maxAge: 2*60*60*1000});
                client.query(`INSERT INTO session VALUES($1,$2,to_timestamp($3))`, [hash, req.body.usernamel, Date.now()+2*60*60*1000], async(err) => {
                  if(err) return res.send(err);
                  frf = req.body.usernamel;
                  console.log(result.rows);
                  console.log('verbena')
                  client.query(`SELECT * FROM lecture WHERE $1 = l_username;`, [frf], async (err, result1)=> {
                    if(err) return res.send(err);
                    done();
                    console.log("AAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
                    console.log(result1.rows);
                    console.log('valjda sam ovde');
                    console.log(result.rows[i].admin);
                    return res.render('predavac', {title: 'predavac', username: req.body.usernamel, tabela: result1.rows, admin: result.rows[i].admin});
                  })
                })
              });
            } else {
              console.log('netacna sifra');
              return res.status(204).send();
            }
        }
      }
      async () => {return res.status(204).send();}
      //console.log(result.rows);
    })
  })
})
//za izbrisati
router.get('/lecture/:code', async(req,res, result)=>{
  console.log('u otvaranju predavanja backend');
  console.log('iiiii');
  console.log(req.params.code)
  pool.connect(async (err,client,done) => {
    if(err) return res.send(err);
    client.query(`SELECT code FROM lecture where code = $1`, [req.params.code], async(err, result) => {
      done()
      if(err) return err;
      else {
        console.log(result.rows[0].code);
        return res.render('lecture', {title: 'bilokako'});
      }
    })
  })
})
module.exports = router;
