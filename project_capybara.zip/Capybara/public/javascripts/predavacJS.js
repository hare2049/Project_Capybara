//var kk = document.getElementById("#code").textContent;
//<%=$('#code').text()%>
function kreirajPredavanje(){
    console.log('aaaaaaa');
    console.info('aaaaaa');
    $.ajax({
        url: "/lectures",
        method: "POST",
        data:{
            'code': $('#code').val(),
            'title': $('#title').val(),
            'time': $('#time').val(),
            'image': $('#image').val(),
            'l_username': $('#spanZaUsername').text()
        },
        dataType: 'json',
        success: async (res) => {
            //console.log('nesto');
            //console.info('nesto');
            location.reload(true);

            //OVDE NASTAVITI!

            //return res.render('predavac', {title: 'predavac', username: req.body.usernamel, tabela: result.rows});
        }
    });
}

//ovo radi ali treba staviti da bude za code a ne ovako
function izbrisiPredavanje(kod){
    console.log('izbrisiPredavanje')
    $.ajax({
        url: "/deleteLecture",
        method: "DELETE",
        data:{
            'code': $('#' + kod).text(),
        },
        dataType: 'json',
        success: async (res) => {
            location.reload(true);
        }
    })
}

function kopirajKod(kod){
    navigator.clipboard.writeText($('#' + kod).text());
    alert('Copied code: ' + $('#' + kod).text());
}

function otvoriPredavanje(kod){
    /*
    console.log('u otvaranju predavanja frontend');
    console.log($('#' + kod).text());
    console.log('aaaa');*/
   // console.log('/lecture/'+$('#' + kod).text())
    console.log('/lecture/' + $('#' + kod).text())
    $.ajax({
        url: ('/lecture/' + $('#' + kod).text()),
        method: "GET",
        /*
        data:{
            'code': $('#' + kod).text(),
        },
        dataType: 'json',
        success: async (res) => {
            console.log('successss')
            //res.render('lecture');
            //location.reload(true);
        }*/
    })
}

function logout(){
    console.log('tu sam');
    document.cookie.split(";").forEach(function(c) { document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/"); });
    $.ajax({
        url: '/',
        method: 'GET',
        success: function (){
            location.reload();
        }
    })
}