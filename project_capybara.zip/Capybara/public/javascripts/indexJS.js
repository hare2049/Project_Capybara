
function passwordLength(){
    const pass = $('#password1')[0];
    if(pass.value.length === 0){
        $('#msg2').html('');
    }
    else if(pass.value.length < 3){
        $('#msg2').css('color','red').html('x');
    }
    else if(pass.value.length >= 3){
        $('#msg2').css('color','green').html('✓');
    }
}

function usernameCheck(){
    $.ajax({
        url: "/usernames",
        method: "GET",
        success: async (res) => {
            function boolCheck(username, usernames){
                for(let i = 0; i < usernames.length; i++){
                    if(username === usernames[i].username) {
                        return true;
                    }
                }
                return false;
            }

            const username = $('#username').val();

            if(username.length === 0){
                $('#msg1').html('');
            }
            else if(boolCheck(username, res.response))
            {
                $('#msg1').css('color','red').html('Taken!');
            }
            else
            {
                $('#msg1').css('color','green').html('✓');
            }
        }
    });
}

function usernameCheck2(){
    $.ajax({
        url: "/usernames",
        method: "GET",
        success: async (res) => {
            function boolCheck(username, usernames){
                for(let i = 0; i < usernames.length; i++){
                    if(username === usernames[i].username) {
                        return true;
                    }
                }
                return false;
            }

            const username = $('#usernamel').val();

            if(username.length === 0){
                $('#msg5').html('');
            }
            else if(boolCheck(username, res.response))
            {
                $('#msg5').css('color','green').html('✓');
            }
            else
            {
                $('#msg5').css('color','red').html('x');
            }
        }
    });
}

function passwordMatch(){
    const pass1 = $('#password1')[0];
    const pass2 = $('#password2')[0];
    if(pass2.value.length === 0){
        $('#msg3').html('');
    }
    else if(pass1.value !== pass2.value) {
        $('#msg3').css('color','red').html('x');
    }
    else{
        $('#msg3').css('color','green').html('✓');
    }
}

function emailCheck(){
    $.ajax({
        url: "/emails",
        method: "GET",
        success: function (res) {
            function boolCheck(email, emails) {
                for (let i = 0; i < emails.length; i++) {
                    console.log(emails[i].email)
                    if (email === emails[i].email) {
                        return true;
                    }
                }
                return false;
            }

            const email = $('#email').val();

            if (email.length === 0) {
                $('#msg4').html('');
            } else if (!email.toLowerCase().match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) {
                $('#msg4').css('color', 'red').html('x');
            } else if (boolCheck(email, res.response)){
                $('#msg4').css('color','red').html('Taken!');
            }
            else {
                $('#msg4').css('color', 'green').html('✓');
            }
        }
    });
}



function showLogIn(){
    $('#logInSelectButton').css('background','#fce88d');
    $('#signUpSelectButton').css('background','#f4c554');
    $('#logIn').css('display','block');
    $('#signUp').css('display','none');
}
function showSignUp(){
    $('#logInSelectButton').css('background','#f4c554');
    $('#signUpSelectButton').css('background','#fce88d');
    $('#logIn').css('display','none');
    $('#signUp').css('display','block');
}



