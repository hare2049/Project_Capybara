var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var session = require('express-session');
var bcrypt = require('bcrypt');


var indexRouter = require('./routes/index');
var predavacRouter = require('./routes/predavac');
var lectureRouter = require('./routes/lecture');


var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


app.use(express.static(path.join(__dirname, '/node_modules/bootstrap/dist/css')))
app.use(express.static(path.join(__dirname, '/node_modules/bootstrap/dist/js')))
app.use(express.static(path.join(__dirname, '/node_modules/jquery/dist/')))

app.use('/lecture', lectureRouter);

app.use(function(req,res,next){

  if(req.cookies.secret === undefined || req.cookies.yes === '1') {
    console.log('U glavnoj');
    console.log(req.url)
    if (req.url === '/predavanja' || req.url === '/usernames' || req.url === '/emails'
        || req.url === '/' || req.url === '/predavac' || req.url === '/signup' || req.url === '/login'
        || req.url === '/favicon.ico' || req.url === '/lectures' || req.url === '/deleteLecture' || req.url === '/lecture') {
      console.log('proslo');
      next();
    } else if (req.url === '/favicon.ico') {
      res.writeHead(200, {'Content-Type': 'image/x-icon'});
      res.end();
    } else {
      console.log('op op op');
      return res.redirect('/');
    }
  }
  else {
    return res.render('index', {title: 'Capybara'});
  }
});

app.use('/', indexRouter);
app.use('/predavac', predavacRouter);



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
